/* this is a dummy file, that is needed for compiling files that are 
 * generated with flex under Windows 95/NT. 
 */
#if defined(_MSC_VER)
#include <io.h>
#endif

